import gspread

from oauth2client.service_account import ServiceAccountCredentials
from functions import user_management, photo_function, open_images, probability_sezione1

############ SETTAGGIO AMBIENTE #############

# adesso dobbiamo creare uno scope
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/spreadsheets",
         "https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name("creds.json", scope)

client = gspread.authorize(creds)
sheet = client.open("SondaggioProgetto").sheet1

############ INIZIO MANIPOLAZIONE DATI ###############

# data è una lista di dizionari
data = sheet.get_all_records()

print(data)

# in questo modo abbiamo una lista di chiavi esclusa quella relative alle informazioni cronologiche
keys = list(data[0].keys())[1:]

print(keys)

# categorie psicologiche
categories = ("Leone", "Lontra", "Golden Retriever", "Castoro")

# alla funzione passiamo come parametro i dati, le categorie, e tutte le chiavi
# keys[1:] sono le chiavi relative alle risposte
# keys[0] sono le domande relative alle foto scelte
users = user_management(data, categories, keys[4:], keys[0:4])

print(users[0])

categorie1 = ("Cane", "Gatto")
p = probability_sezione1(users[0], categorie1)

print("Probabilità di scegliere i cani: ", p[categorie1[0]])
print("Probabilità di scegliere i gatti: ", p[categorie1[1]])


