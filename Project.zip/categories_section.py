sezione1 = ("Cane", "Cane", "Gatto", "Cane", "Cane", "Gatto", "Gatto", "Cane", "Gatto", "Cane",
            "Gatto", "Cane", "Gatto", "Gatto", "Cane", "Gatto", "Gatto", "Cane", "Cane", "Gatto")

sezione2 = ("", "", "", "", "", "", "", "", "", "",
            "", "", "", "", "", "", "", "", "", "")

sezione3 = ("", "", "", "", "", "", "", "", "", "",
            "", "", "", "", "", "", "", "", "", "")

sezione4 = ("", "", "", "", "", "", "", "", "", "",
            "", "", "", "", "", "", "", "", "", "")