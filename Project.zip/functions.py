import numpy as np
import random
from constants import num_answers, num_rows, num_columns, sezioni, sezioni_label, categorie


def users_management(data, categories, keys_answers, key_photos):
    i = 0
    users_dataset = []

    for d in data:

        # questo è l'utente che deve essere inserito
        user = {"Numero campione": i, "Categoria psicologica": ""}
        i += 1

        # grazie a questo ciclo per ogni sezione di foto si crea una tupla contente gli interi
        for s in range(0, 4):
            photos_section = d[key_photos[s]].split(", ")
            for h in range(0, num_answers):
                photos_section[h] = int(photos_section[h])

            user[sezioni[s]] = tuple(photos_section)

        answers = []
        for key in keys_answers:
            answers.append(d[key])

        # trasformiamo la lista di risposte in un numpy array e lo modifichiamo rendendolo
        # una matrice con n_rows = 10  e n_columns = 4
        answers = np.array(answers)
        answers.shape = (num_rows, num_columns)

        # si sommano i valori di ciascuna colonna per vedere i punteggi per ciascuna categoria
        category_marks = answers.sum(axis=0)

        user["Categoria psicologica"] = categories[manage_same_value(category_marks)]
        users_dataset.append(user)

    return users_dataset


def manage_same_value(category_marks):
    occorrenze_max = category_marks.tolist().count(np.max(category_marks))
    indexes = []

    if occorrenze_max > 1:
        max = np.max(category_marks)
        for i in range(0, category_marks.size):
            if category_marks[i] == max:
                indexes.append(i)

        index = random.choice(indexes)

    else:
        index = np.argmax(category_marks)

    return index


# funzione che divide gli utenti per categoria in modo da rendere più semplice svolgere i calcoli
# funzione che returna un dizionario di liste, dove ogni lista contiene dizionari
# le chiavi del dizionario principale sono i nomi delle categorie psicologiche
def users_division(users, cat_ps):
    users_by_category = {cat_ps[0]: [], cat_ps[1]: [], cat_ps[2]: [], cat_ps[3]: []}

    for user in users:
        users_by_category[user["Categoria psicologica"]].append(user)

    return users_by_category


# calcola il valore atteso per una determinata categoria
def valore_atteso_psyche(users_by_category, cat_psicologica, categorie_photo):

    # una volta calcolata la probabilità per una categoria possiamo calcolare i valori attesi
    dict_psyche = probability_psyche_category(users_by_category, cat_psicologica, categorie_photo)

    # dict_psyche è un dizionario di liste
    # rimuoviamo i duplicati e poi contiamo quante volte ogni elemento è contenuto lì dentro
    # questa lista contiene i valori attesi per i cani, le auto, i quadri e il cielo soleggiato
    val_attesi_categoria = []

    dict = {"Cane": [], "Auto": [], "Quadro": [], "Soleggiato": []}
    keys_dict = list(dict.keys())

    # il dizionario prodotto con questo ciclo contiene le probabilità per tutti gli utenti di quella
    # categoria per ciascuna prima label di ogni sezione di foto
    for key in dict_psyche.keys():
        for i in range(0, 4):
            dict[keys_dict[i]].append(dict_psyche[key][i][keys_dict[i]])

    # ora dobbiamo togliere i duplicati
    # possiamo scegliere qualiasi tipo di struttura dati
    # optiamo per un dizionario di insiemi
    dict_support = {"Cane": {}, "Auto": {}, "Quadro": {}, "Soleggiato": {}}
    for key in dict.keys():
        dict_support[key] = set(dict[key])

    # ora dobbiamo controllare quante volte ogni elemento è nella lista di quella categoria
    dict_quantity_prob = {"Cane": {}, "Auto": {}, "Quadro": {}, "Soleggiato": {}}
    for key in dict_support.keys():
        for e in list(dict_support[key]):
            dict_quantity_prob[key][e] = dict[key].count(e) / len(dict[key])

    dict_valori_attesi = {"Cane": 0, "Auto": 0, "Quadro": 0, "Soleggiato": 0, "Gatto": 0, "Moto": 0, "Scultura": 0,
                          "Coperto": 0}
    i = 4
    l1 = list(dict_valori_attesi.keys())
    for key in dict_quantity_prob.keys():
        for key1 in dict_quantity_prob[key].keys():
            dict_valori_attesi[key] += (dict_quantity_prob[key][key1] * key1)
            dict_valori_attesi[key] = round(dict_valori_attesi[key], 1)
            dict_valori_attesi[l1[i]] = round(1 - dict_valori_attesi[key], 1)

        i += 1

    return dict_valori_attesi

# con questa funzione calcoliamo anche la varianza per ciascuna categoria su ciascuna sezione
def calcolo_varianza_psyche():
    pass



# funzione che calcola le probabilità per ciascuna sezione per gli utenti
# di una categoria determinata
def probability_psyche_category(users_by_category, cat_psicologica, categorie_photo):

    # dizionario con numero campione e probabilità per sezione, per utente
    dict = {}
    for user in users_by_category[cat_psicologica]:
        dict[user["Numero campione"]] = []

    # lista di probabilità per un utente per una sezione
    probability = []
    for user in users_by_category[cat_psicologica]:
        for i in range(0, 4):
            probability.append(probability_section(user, categorie_photo[i], i))

        dict[user["Numero campione"]] = probability
        probability = []

    return dict


# funzione che calcola le probabilità per un solo utente, per una categoria passando il numero della sezione
def probability_section(user, categorie, section_number):
    # lista di foto per la sezione desiderata
    photos = photo_function(user)[section_number]

    # modifichiamo gli indici facendoli partire da 0
    sezione_photos = []
    for i in photos:
        sezione_photos.append(i - 1)

    # memorizzazione delle label corrispondenti alle foto scelte
    sezione_label = []
    for s in sezione_photos:
        sezione_label.append(sezioni_label[section_number][s])

    p_campioni_dict = {}
    for i in range(0, 2):
        p_campioni_dict[categorie[i]] = sezione_label.count(categorie[i]) / num_answers

    return p_campioni_dict


# funzione che returna una lista di tuple, di foto
def photo_function(user):
    # una lista di tuple, dove ogni tupla è la selezione di foto per quell'utente
    photo_list_section = []

    for s in sezioni:
        photo_list_section.append(user[s])

    return photo_list_section
