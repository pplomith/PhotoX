import numpy as np
from PIL import Image
from photo_paths import photos_section_1
from categories_section import sezione1

num_answers = 10
num_rows = 10
num_columns = 4
sezioni = ("Sezione 1", "Sezione 2", "Sezione 3", "Sezione 4")


def user_management(data, categories, keys_answers, key_photos):
    i = 0
    users_dataset = []

    for d in data:

        # questo è l'utente che deve essere inserito
        user = {"Numero campione": i, "Cp": ""}
        i += 1

        # grazie a questo ciclo per ogni sezione di foto si crea una tupla contente gli interi
        for s in range(0, 4):
            photos_section = d[key_photos[s]].split(", ")
            print("Photos_section: ", s, photos_section)
            for h in range(0, num_answers):
                photos_section[h] = int(photos_section[h])

            user[sezioni[s]] = tuple(photos_section)

        print("Utente", user)

        answers = []
        for key in keys_answers:
            answers.append(d[key])

        print(answers)

        # trasformiamo la lista di risposte in un numpy array e lo modifichiamo rendendolo
        # una matrice con n_rows = 10  e n_columns = 4
        answers = np.array(answers)
        answers.shape = (num_rows, num_columns)

        print("Risposte\n", answers)

        # si sommano i valori di ciascuna colonna per vedere i punteggi per ciascuna categoria
        category_marks = answers.sum(axis=0)
        category_marks = np.array(category_marks)

        print("I voti sono: ", category_marks)

        index = np.argmax(category_marks)
        user["Cp"] = categories[index]

        users_dataset.append(user)

    return users_dataset


# funzione che returna una lista di tuple, di foto
def photo_function(user):
    # una lista di tuple, dove ogni tupla è la selezione di foto per quell'utente
    photo_list_section = []

    for s in sezioni:
        photo_list_section.append(user[s])

    return photo_list_section


# funzione per indicizzare le immagini
# photos_user: indici delle immagini per ciascuna sezione
def open_images(photos_user):
    section1 = photos_user[0]

    for index in section1:
        img = Image.open(photos_section_1[index - 1])
        img.show()


# viene passato come parametro un utente tra tutti quelli che hanno risposto al questionario
def probability_sezione1(user, categorie):

    n_animali = []

    # lista di tuple per un utente
    photos = photo_function(user)

    # stampa delle foto selezionate dall'utente users[0] per ciascuna sezione
    for photo in photos:
        print(photo)

    sezione_1_foto = []

    # in questo modo modifichiamo gli indici facendoli partire da 0 e stampiamo
    for i in photos[0]:
        sezione_1_foto.append(i - 1)

    print("Foto sezione1: ", sezione_1_foto)

    sezione1_label = []
    for s in sezione_1_foto:
        sezione1_label.append(sezione1[s])

    print(sezione1_label)

    for c in categorie:
        n_animali.append(sezione1_label.count(c))

    print(n_animali)

    p_animali_dict = {}
    for i in range (0, 2):
        p_animali_dict[categorie[i]] = n_animali[i] / num_answers

    return p_animali_dict
