import numpy as np


def user_management(data_sheet, categories, keys_answers, key_photos):

    i = 0
    users_dataset = []

    for d in data_sheet:

        user = {"Numero campione": i, "Nome": "", "Cognome": "", "Cp": "", "Foto selezionate": []}
        i += 1

        user["Nome"] = d["Nome"]
        user["Cognome"] = d["Cognome"]
        user["Foto selezionate"] = tuple(d[key_photos].split(", "))

        answers = []
        for key in keys_answers:
            answers.append(d[key])

        # trasformiamo la lista di risposte in un numpy array e lo modifichiamo rendendolo
        # una matrice con n_rows = 10  e n_columns = 4
        answers = np.array(answers)
        answers.shape = (10, 4)

        # si sommano i valori di ciascuna colonna per vedere i punteggi per ciascuna categoria
        category_marks = answers.sum(axis=0)
        category_marks = np.array(category_marks)

        index = np.argmax(category_marks)
        user["Cp"] = categories[index]

        users_dataset.append(user)

    return users_dataset;
