import gspread

from oauth2client.service_account import ServiceAccountCredentials
from functions import user_management

############ SETTAGGIO AMBIENTE #############

# adesso dobbiamo creare uno scope
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/spreadsheets",
         "https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/drive"]

creds = ServiceAccountCredentials.from_json_keyfile_name("creds.json", scope)
client = gspread.authorize(creds)
sheet = client.open("SondaggioProgetto").sheet1

############ INIZIO MANIPOLAZIONE DATI ###############

# data è una lista di dizionari
data = sheet.get_all_records()

# in questo modo abbiamo una lista di chiavi esclusa quella relative alle informazioni cronologiche
keys = list(data[0].keys())[1:]

# lista senza nome e cognome e senza le risposte per le domande
keys_answers= keys[3:]

# categorie psicologiche
categories = ("Leone", "Lontra", "Golden Retriever", "Castoro")

users = user_management(data, categories, keys_answers, keys[0])

for u in users:
    print(u)

