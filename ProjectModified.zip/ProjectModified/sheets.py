import gspread

from oauth2client.service_account import ServiceAccountCredentials
from functions import user_management
from functions import photo_function
from functions import open_images

############ SETTAGGIO AMBIENTE #############

# adesso dobbiamo creare uno scope
scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/spreadsheets",
         "https://www.googleapis.com/auth/drive.file", "https://www.googleapis.com/auth/drive"]

creds = ServiceAccountCredentials.from_json_keyfile_name("creds.json", scope)
client = gspread.authorize(creds)
sheet = client.open("SondaggioProgetto").sheet1

############ INIZIO MANIPOLAZIONE DATI ###############

# data è una lista di dizionari
data = sheet.get_all_records()

# in questo modo abbiamo una lista di chiavi esclusa quella relative alle informazioni cronologiche
keys = list(data[0].keys())[1:]

# categorie psicologiche
categories = ("Leone", "Lontra", "Golden Retriever", "Castoro")

# alla funzione passiamo come parametro i dati, le categorie, e tutte le chiavi
# keys[1:] sono le chiavi relative alle risposte
# keys[0] sono le domande relative alle foto scelte
users = user_management(data, categories, keys[1:], keys[0])

for u in users:
    print(u)

photos = photo_function(users)

for photo in photos:
    print(photo)

open_images(photos[2])


