import numpy as np
from PIL import Image


def user_management(data_sheet, categories, keys_answers, key_photos):
    i = 0
    users_dataset = []

    for d in data_sheet:

        user = {"Numero campione": i, "Cp": "", "Foto selezionate": []}
        i += 1

        user["Foto selezionate"] = tuple(d[key_photos].split(", "))

        answers = []
        for key in keys_answers:
            answers.append(d[key])

        # trasformiamo la lista di risposte in un numpy array e lo modifichiamo rendendolo
        # una matrice con n_rows = 10  e n_columns = 4
        answers = np.array(answers)
        answers.shape = (10, 4)

        # si sommano i valori di ciascuna colonna per vedere i punteggi per ciascuna categoria
        category_marks = answers.sum(axis=0)
        category_marks = np.array(category_marks)

        index = np.argmax(category_marks)
        user["Cp"] = categories[index]

        users_dataset.append(user)

    return users_dataset;


def photo_function(users_list):
    # una lista di tuple che racchiude gli indici delle immagini scelte da tutti gli utenti
    photo_list = []

    for user in users_list:

        # assegna alla tupla photo_selected i numeri delle foto selezionate dall'utente
        photo_selected = user["Foto selezionate"]

        # crea una lista che conterrà i numeri delle foto selezionate e che sarà trasformata in una tupla
        photo_selected_converted = []

        # ciclo che itera la tupla photo_selected converte le stringhe in interi
        for photo_chosen in photo_selected:
            photo_selected_converted.append(int(photo_chosen))

        photo_selected_converted = tuple(photo_selected_converted)
        photo_list.append(photo_selected_converted)

    return photo_list


# funzione per indicizzare le immagini
# photos_user sono gli indici delle immagini
def open_images(photos_user):

    print("Photos user: ")
    print(photos_user)

    tuple_of_photos = (
    "/Users/memex_99/Desktop/FIA/Progetto/FotoProgetto/1.jpg", "/Users/memex_99/Desktop/FIA/Progetto/FotoProgetto/2.jpg",
    "/Users/memex_99/Desktop/FIA/Progetto/FotoProgetto/3.jpg", "/Users/memex_99/Desktop/FIA/Progetto/FotoProgetto/4.jpg",
    "/Users/memex_99/Desktop/FIA/Progetto/FotoProgetto/5.jpeg", "/Users/memex_99/Desktop/FIA/Progetto/FotoProgetto/6.jpeg",
    "/Users/memex_99/Desktop/FIA/Progetto/FotoProgetto/7.jpeg", "/Users/memex_99/Desktop/FIA/Progetto/FotoProgetto/8.jpeg",
    "/Users/memex_99/Desktop/FIA/Progetto/FotoProgetto/9.jpg", "/Users/memex_99/Desktop/FIA/Progetto/FotoProgetto/10.jpg")

    for index in photos_user:
        img = Image.open(tuple_of_photos[index - 1])
        img.show()
